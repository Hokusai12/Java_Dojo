import java.util.ArrayList;


public class Order {
	String name;
	double total;
	boolean ready;
	ArrayList<Item> items;
}
