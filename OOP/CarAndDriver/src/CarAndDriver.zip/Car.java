
public class Car {
	protected int gas = 10;
	
	protected void printGas() {
		System.out.println(gas + "/10 gas left.");
	}
	
	protected void gameOver() {
		System.out.println("Game Over! Watch that gas gauge!");
	}
}
