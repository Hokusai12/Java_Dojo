
public class GorillaTest {

	public static void main(String[] args) {
		//Gorilla Test
		Gorilla cutie = new Gorilla();
		System.out.println("-----Gorilla Test-----");
		
		cutie.throwObject();
		cutie.throwObject();
		cutie.throwObject();
		
		cutie.eatBanana();
		cutie.eatBanana();
		
		cutie.climb();
		
		cutie.displayEnergy();
	}

}
