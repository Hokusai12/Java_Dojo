
public class TestOrders {

	public static void main(String[] args) {
		// Item objects
		Item item1 = new Item("drip coffee", 5);
		Item item2 = new Item("mocha", 7.25);
		Item item3 = new Item("latte", 6.3);
		Item item4 = new Item("cappucino", 5.75);

//		Test Case - 1
//		Order order1 = new Order();
//		Order order2 = new Order();
//		
//		order1.display();
//		order2.display();

//		
//		Test Case - 2
//		Order order1 = new Order("Jeffery");
//		Order order2 = new Order("Bones");
//		Order order3 = new Order("Alegiz");

//		Test Case - 3
//		order1.addItem(item2);
//		order1.addItem(item3);
//
//		order2.addItem(item1);
//		order2.addItem(item1);
//		order2.addItem(item1);
//
//		order3.addItem(item4);
//		order3.addItem(item3);
//		order3.addItem(item2);
//		order3.addItem(item4);
//		order3.addItem(item3);
//		
//		Test Case - 4
//		
//		order1.setReady(true);
//		order2.setReady(true);
//		
//		System.out.println(order1.getStatusMessage());   --true
//		System.out.println(order2.getStatusMessage());   --true
//		System.out.println(order3.getStatusMessage());   --false

//		Test Case - 5
//		System.out.println(order1.getOrderTotal());
//		System.out.println(order2.getOrderTotal());
//		System.out.println(order3.getOrderTotal());
		
//		Test Case - 6
//		order1.display();
//		order2.display();
//		order3.display();
	}

}
