package com.ianhearne.burgertracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BurgertrackerApplication {

	public static void main(String[] args) {
		SpringApplication.run(BurgertrackerApplication.class, args);
	}

}
