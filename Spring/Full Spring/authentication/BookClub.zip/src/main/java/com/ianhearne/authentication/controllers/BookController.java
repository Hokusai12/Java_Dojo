package com.ianhearne.authentication.controllers;

import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ianhearne.authentication.models.Book;
import com.ianhearne.authentication.services.BookService;
import com.ianhearne.authentication.services.UserService;

@Controller
@RequestMapping("/books")
public class BookController {
	@Autowired
	BookService bookService;
	@Autowired
	UserService userService;

	////	GET MAPPINGS	////
	
	@GetMapping("")
	public String welcome(Model model, HttpSession session) {
		if(session.getAttribute("userId") == null) {
			return "redirect:/";
		}
		Long userId = (Long) session.getAttribute("userId");
		List<Book> allBooks = bookService.getAll();
		
		model.addAttribute("user", userService.findById(userId));
		model.addAttribute("allBooks", allBooks);
		return "homepage.jsp";
	}
	
	@GetMapping("/new")
	public String addBook(@ModelAttribute("newBook") Book newBook, Model model, HttpSession session) {
		if(session.getAttribute("userId") == null) {
			return "redirect:/";
		}
		Long userId = (Long) session.getAttribute("userId");
		model.addAttribute("userId", userId);
		return "new-book.jsp";
	}
	
	@GetMapping("/{bookId}")
	public String showBook(@PathVariable(name="bookId") Long bookId, Model model, HttpSession session) {
		if(session.getAttribute("userId") == null) {
			return "redirect:/";
		}
		Long userId = (Long) session.getAttribute("userId");
		Book book = bookService.findById(bookId);
		
		model.addAttribute("userId", userId);
		model.addAttribute("book", book);
		return "show-book.jsp";
	}
	
	@GetMapping("/{bookId}/edit")
	public String editBook(@PathVariable Long bookId, Model model, HttpSession session) {
		if(session.getAttribute("userId") == null) {
			return "redirect:/";
		}
		Long userId = (Long) session.getAttribute("userId");
		Book book = bookService.findById(bookId);
		if(!session.getAttribute("userId").equals(book.getUser().getId())) { 
			return "redirect:/books/" + book.getId().toString();
		}
		model.addAttribute("userId", userId);
		model.addAttribute("book", book);
		return "edit-book.jsp";
	}
	
	////	PUT MAPPINGS	////
	
	@PutMapping("/{id}/update")
	public String updateBook(@PathVariable("id") Long bookId, @Valid @ModelAttribute("book") Book book, BindingResult result, HttpSession session) {
		if(session.getAttribute("userId") == null) {
			return "redirect:/";
		}
		if(result.hasErrors()) {
			return "/edit-book.jsp";
		}
		bookService.updateBook(book);
		return "redirect:/books";
		
	}
	
	////	POST MAPPINGS    ////
	
	@PostMapping("/add-book")
	public String saveBook(@Valid @ModelAttribute("newBook") Book newBook, BindingResult result, HttpSession session) {
		if(session.getAttribute("userId") == null) {
			return "redirect:/";
		}
		if(result.hasErrors()) {
			return "/new-book.jsp";
		}
		bookService.addBook(newBook);
		return "redirect:/books";
	}
	
	//// DELETE MAPPINGS ////
	@DeleteMapping("{id}/delete")
	public String deleteBook(@PathVariable Long id) {
		bookService.delete(id);
		return "redirect:/books";
	}
}
