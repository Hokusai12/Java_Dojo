public class FirstJavaProgram {
    public static void main(String[] args) {
        System.out.println("My name is Ian Hearne");
        System.out.println("I am 20 years old");
        System.out.println("I live in Bentonville, AR");
    }
}